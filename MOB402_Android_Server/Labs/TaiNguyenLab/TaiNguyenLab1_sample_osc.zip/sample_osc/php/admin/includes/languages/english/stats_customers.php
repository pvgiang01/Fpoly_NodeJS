<?php
/*
  $Id: stats_customers.php,v 1.6 2002/03/30 15:54:15 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Best Customer Orders-Total');

define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_CUSTOMERS', 'Customers');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Total Purchased');
?>