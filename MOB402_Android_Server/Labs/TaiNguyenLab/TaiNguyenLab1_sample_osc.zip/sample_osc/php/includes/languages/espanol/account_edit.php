<?php
/*
  $Id: account_edit.php,v 1.9 2003/07/08 16:45:35 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Editar Cuenta');

define('HEADING_TITLE', 'Datos de Mi Cuenta');

define('MY_ACCOUNT_TITLE', 'Mi Cuenta');

define('SUCCESS_ACCOUNT_UPDATED', 'Se ha actualizado su cuenta correctamente.');
?>
