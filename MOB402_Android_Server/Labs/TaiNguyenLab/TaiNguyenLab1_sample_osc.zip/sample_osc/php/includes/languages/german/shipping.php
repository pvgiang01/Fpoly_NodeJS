<?php
/*
  $Id: shipping.php,v 1.4 2002/04/17 15:57:07 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Liefer- und Versandkosten');
define('HEADING_TITLE', 'Liefer- und Versandkosten');

define('TEXT_INFORMATION', 'F&uuml;gen Sie hier Ihre Informationen &uuml;ber Liefer- und Versandkosten ein.');
?>