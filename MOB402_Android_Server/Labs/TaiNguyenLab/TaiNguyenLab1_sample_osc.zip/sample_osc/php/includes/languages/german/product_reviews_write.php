<?php
/*
  $Id: product_reviews_write.php,v 1.10 2003/06/05 23:23:53 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Meinungen');

define('SUB_TITLE_FROM', 'Autor:');
define('SUB_TITLE_REVIEW', 'Ihre Meinung:');
define('SUB_TITLE_RATING', 'Bewertung:');

define('TEXT_NO_HTML', '<small><font color="#ff0000"><b>ACHTUNG:</b></font></small>&nbsp;HTML wird nicht unterst&uuml;tzt!');
define('TEXT_BAD', '<small><font color="#ff0000"><b>SCHLECHT</b></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>SEHR GUT</b></font></small>');

define('TEXT_CLICK_TO_ENLARGE', 'F&uuml;r eine gr&ouml;ssere Darstellung<br>klicken Sie auf das Bild.');
?>