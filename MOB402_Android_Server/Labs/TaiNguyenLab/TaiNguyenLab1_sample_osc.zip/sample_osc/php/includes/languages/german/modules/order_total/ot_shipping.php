<?php
/*
  $Id: ot_shipping.php,v 1.5 2003/07/11 09:04:23 jan0815 Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Versandkosten');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Versandkosten einer Bestellung');

  define('FREE_SHIPPING_TITLE', 'Versandkostenfrei');
  define('FREE_SHIPPING_DESCRIPTION', 'Versandkostenfrei bei einem Bestellwert &uuml;ber %s');
?>
