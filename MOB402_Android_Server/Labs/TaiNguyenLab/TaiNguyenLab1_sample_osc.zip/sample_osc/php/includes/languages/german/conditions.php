<?php
/*
  $Id: conditions.php,v 1.5 2003/07/11 09:04:22 jan0815 Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Allgemeine Gesch&auml;ftsbedingungen');
define('HEADING_TITLE', 'Allgemeine Gesch&auml;ftsbedingungen');

define('TEXT_INFORMATION', 'F&uuml;gen Sie hier Ihre allgemeinen Gesch&auml;ftsbedingungen ein.');
?>
