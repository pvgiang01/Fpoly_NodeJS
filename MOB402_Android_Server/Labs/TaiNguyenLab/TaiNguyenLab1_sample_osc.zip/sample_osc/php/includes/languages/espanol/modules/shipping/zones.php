<?php
/*
  $Id: zones.php,v 1.4 2002/11/19 01:14:34 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_ZONES_TEXT_TITLE', 'Tarifa por Zona');
define('MODULE_SHIPPING_ZONES_TEXT_DESCRIPTION', 'Tarifa basada en Zonas');
define('MODULE_SHIPPING_ZONES_TEXT_WAY', 'Enviar A');
define('MODULE_SHIPPING_ZONES_TEXT_UNITS', 'kg(s)');
define('MODULE_SHIPPING_ZONES_INVALID_ZONE', 'No hay envio disponible para ese pais.');
define('MODULE_SHIPPING_ZONES_UNDEFINED_RATE', 'No se han podido calcular los gastos de envio');
?>
