<?php
/*
  $Id: footer.php,v 1.26 2003/02/10 22:30:54 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  require(DIR_WS_INCLUDES . 'counter.php');
?>
<table width="715"  border="0" cellspacing="0" cellpadding="0" align="center">
        <tr>
          <td height="24" valign="middle" bgcolor="#4C4C4C"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="3%">&nbsp;</td>
              <td width="97%"><span class="style1"><a href="<?php echo tep_href_link(FILENAME_DEFAULT); ?>" class="top" style="color:#FFFFFF; text-decoration:none">Catalog</a>&nbsp; |&nbsp; <a href="<?php echo tep_href_link(FILENAME_SHIPPING); ?>" class="top" style="color:#FFFFFF; text-decoration:none">Shipping</a> &nbsp;| &nbsp;<a href="<?php echo tep_href_link(FILENAME_ADVANCED_SEARCH); ?>" class="top" style="color:#FFFFFF; text-decoration:none">Search</a> &nbsp;| &nbsp;<a href="<?php echo tep_href_link(FILENAME_SHOPPING_CART); ?>" class="top" style="color:#FFFFFF; text-decoration:none">Shopping Cart</a> &nbsp;| &nbsp;<a href="<?php echo tep_href_link(FILENAME_SPECIALS); ?>" class="top" style="color:#FFFFFF; text-decoration:none">Hot Offers</a> &nbsp;| &nbsp;<a href="<?php echo tep_href_link(FILENAME_CONTACT_US); ?>" class="top" style="color:#FFFFFF; text-decoration:none">Contact us</a></span></td>
            </tr>
          </table></td>
        </tr>
      </table>
<table width="715" height="38"  border="0" cellpadding="0" cellspacing="0" align="center">
        <tr>
          <td width="52%"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="3%">&nbsp;</td>
              <td width="97%"><span class="style7">YourCompany.Com � 2004 | <a href="<?php echo tep_href_link(FILENAME_PRIVACY); ?>" class="top" style="color:#5680A9;text-decoration:none">Privacy Policy</a> | <a href="<?php echo tep_href_link(FILENAME_CONDITIONS); ?>" class="top" style="color:#5680A9;text-decoration:none">Terms Of Use</a></span></td>
            </tr>
          </table></td>
          <td width="48%" align="right"><a href="#"><img src="<?php echo DIR_WS_IMAGES  ?>theme/s4.jpg" width="82" height="26" border="0"></a><a href="#"><img src="<?php echo DIR_WS_IMAGES  ?>theme/s3.jpg" width="41" height="26" border="0"></a><a href="#"><img src="<?php echo DIR_WS_IMAGES  ?>theme/s2.jpg" width="41" height="26" border="0"></a><a href="#"><img src="<?php echo DIR_WS_IMAGES  ?>theme/s1.jpg" width="40" height="26" border="0"></a></td>
        </tr>
    </table>
