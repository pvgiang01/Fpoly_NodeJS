<?php
/*
  $Id: index.php,v 1.1 2002/01/02 13:02:38 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  require('includes/application.php');

  $page_file = 'index.php';
  $page_title = 'Welcome';
  $page_contents = 'index.php';

  require('templates/main_page.php');
?>
